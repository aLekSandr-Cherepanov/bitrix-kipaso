<?
	$MESS["FAST_VIEW_HEADING"] = "Быстрый просмотр";
	$MESS["FAST_VIEW_PRODUCT_PROPERTIES_HEADING"] = "Характеристики";
	$MESS["FAST_VIEW_PRODUCT_MORE_LINK"] = "Больше информации о товаре";
	$MESS["FAST_VIEW_SKU_PROPERTIES_TITLE"] = "Другие варианты товара";
	$MESS["FAST_VIEW_REVIEWS_COUNT"] = "Отзывов";
	$MESS["FAST_VIEW_ADDCART_LABEL"] = "В корзину";
	$MESS["FAST_VIEW_FASTBACK_LABEL"] = "Купить в 1 клик";
	$MESS["FAST_VIEW_WISHLIST_LABEL"] = "В избранное";
	$MESS["FAST_VIEW_COMPARE_LABEL"] = "К сравнению";
	$MESS["FAST_VIEW_AVAILABLE"] = "В наличии";
	$MESS["FAST_VIEW_NOAVAILABLE"] = "Недоступно";
	$MESS["FAST_VIEW_NO_AVAILABLE"] = "Недоступно";
	$MESS["FAST_VIEW_ON_ORDER"] = "Под заказ";
	$MESS["FAST_VIEW_ADDCART_LABEL"] = "В корзину";
	$MESS["FAST_VIEW_ARTICLE_LABEL"] = "Артикул:";
	$MESS["FAST_VIEW_OLD_PRICE_LABEL"] = "Старая цена:";
	$MESS["FAST_VIEW_REQUEST_PRICE_LABEL"] = "Цена по запросу";
	$MESS["FAST_VIEW_REQUEST_PRICE_BUTTON_LABEL"] = "Запросить цену";
	$MESS["FAST_VIEW_DESCRIPTION_TITLE"] = "Описание товара";
	$MESS["FAST_VIEW_REVIEWS_LABEL"] = "Рейтинг";
	$MESS["FAST_VIEW_QUANTITY_LABEL"] = "Кол-во:";
	$MESS["FAST_VIEW_TIMER_DAY_LABEL"] = "Дней";
	$MESS["FAST_VIEW_TIMER_HOUR_LABEL"] = "Часов";
	$MESS["FAST_VIEW_TIMER_MINUTE_LABEL"] = "Минут";
	$MESS["FAST_VIEW_TIMER_SECOND_LABEL"] = "Секунд";
	$MESS["FAST_VIEW_SUBSCRIBE_LABEL"] = "Подписаться";
?>